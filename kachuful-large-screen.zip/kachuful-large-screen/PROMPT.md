# Task: purpose-built desktop and tablet UI for Kachuful

Phone UI is done and must NOT change. Add a separate large-screen experience, using the designs in `design/` as the reference. Do not just make the phone layout responsive.

## How to read the design files
- `design/*.dc.html` are static HTML boards (one per screen). They need the design tool's runtime to render, so read the markup for exact sizes, spacing, copy and structure. The live canvas is the visual reference: CANVAS_URL (ask the user for it if missing). `design/kachuful.css` holds the tokens and component classes (colours, glass cards, keys, chips, deltas). Map these to the existing Tailwind theme and tokens. Do not copy the CSS as-is.
- Ignore the `<x-dc>`, `<dc-import>` and `{{...}}` tags. They are design-tool syntax, not app code. `canvas.json` is just the board layout.
- `Table.dc.html` has the round-table geometry (seat positions, direction arcs, felt). Port the maths, not the markup.

## Breakpoints
- Phone (< 768px): existing UI, untouched.
- Tablet portrait (768-1023px): `TP-*` boards. Top bar instead of rail.
- Tablet landscape (1024-1279px): `TL-*` boards. Rail, two columns.
- Desktop (>= 1280px): the 1440x900 boards. Rail, three panes. At >= 1920px keep the same layout and let the content area grow, no stretching of text or keys.
Use one set of screens and components with layout switching by breakpoint. Reuse the same state, game logic and store. No duplicated logic.

## Screens (design file -> what to build)
- Main -> Home: hero, New game, How to play, Resume card with live table.
- Setup -> single-page split view: players, seats, dealer, game length left; table preview and Deal right.
- Bidding / Play / Results (+ TL-, TP- variants) -> ONE persistent workspace: round table, action pane (step tracker, bidder, number pad, bid meter, chips, confirm), live score panel. Switching step must not unmount the table or scores.
- Summary -> leaderboard with rank movement, score-history chart, Next-up card.
- Winner -> podium, ranking, highlights, history chart.
- Scoreboard -> full rounds-by-players grid + Edit-round side panel.
- Rules, Upcoming -> right-side drawers over any screen.
- Shared: Rail (nav, undo, settings), ScorePanel (live and projected-with-deltas), Table.

## Behaviour to add
- Keyboard (desktop and tablet with keyboard): 0-9 pick bid, Enter confirm, Z undo, E edit bids, R rematch on Winner, Esc close drawer, ? shows a shortcuts sheet. Show shortcuts as hints in the UI like the designs. Hide hints on touch-only devices.
- Touch targets >= 48px; bid keys 64-76px on tablet. Visible focus rings. Respect prefers-reduced-motion.
- Drawers and side panels: focus trap, Esc to close, return focus to the trigger.
- Keep the existing Framer Motion springs. Panels slide in from the side they sit on.
- Game rules and the dealer's locked bid come from existing logic. Don't re-implement them.

## Data note
The designs use one demo game (5 players, round 7 of 13, 9 cards, clubs). Numbers are examples. Bind everything to real state.

## Not designed yet (build to match the same style, keep simple)
Menu, Avatar picker, Rename, Share modals; tablet Home, Setup, Winner, Scoreboard (collapse the desktop layouts: columns stack, rail becomes top bar in portrait). The scoring text on the Rules drawer was inferred. Check it against the real rules.

## Process
1. Read the repo and list what exists. Propose the file plan (layout shell, rail/top bar, workspace, panels) before big edits.
2. Build the shell + breakpoint switching first, then the workspace, then the other screens.
3. Verify at 1440x900, 1920x1080, 1180x820, 1024x768, 768x1024 and a phone width. Check there is no horizontal scroll and the phone UI is unchanged. Run lint, typecheck, tests and build. Add tests for keyboard shortcuts.
4. Small commits per screen. Report anything in the design that doesn't fit real data.
