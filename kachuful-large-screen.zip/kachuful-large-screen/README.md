# Kachuful large-screen design

- `design/` - 19 screen boards (.dc.html), tokens (kachuful.css) and layout index (canvas.json)
- `PROMPT.md` - paste into Claude Code

Board sizes: desktop 1440x900 (Main, Setup, Bidding, Play, Results, Summary, Winner, Scoreboard), drawers 520x900 (Rules, Upcoming), tablet landscape 1180x820 (TL-*), tablet portrait 768x1024 (TP-*), components (Table, Rail, ScorePanel).
These files do not render on their own (they need the design tool). Read them as markup/spec; view the live canvas for visuals. They are design files, not app code.
